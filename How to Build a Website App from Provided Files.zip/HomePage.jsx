import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Upload, Leaf, Zap, AlertCircle, Package } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

// Item icons mapping
const itemIcons = {
  "Plastic Bottle": "/src/assets/plastic-bottle-icon.png",
  "Aluminum Can": "/src/assets/aluminum-can-icon.png",
  "T-Shirt": "👕",
  "Banana": "🍌",
  "Glass Bottle": "🍾",
  "Laptop": "💻",
  "Paper Sheet": "📄"
}

// Pixelation function
const pixelateImage = (imageData, pixelSize = 4) => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    const img = new Image()
    
    img.onload = () => {
      // Set canvas size - larger for better detail
      const targetSize = 128 // Increased from 64 for better clarity
      canvas.width = targetSize
      canvas.height = targetSize
      
      // Disable image smoothing for pixelated effect
      ctx.imageSmoothingEnabled = false
      
      // Draw image scaled down
      ctx.drawImage(img, 0, 0, targetSize, targetSize)
      
      // Get image data and pixelate
      const imageData = ctx.getImageData(0, 0, targetSize, targetSize)
      const data = imageData.data
      
      // Apply pixelation effect with smaller pixel blocks
      for (let y = 0; y < targetSize; y += pixelSize) {
        for (let x = 0; x < targetSize; x += pixelSize) {
          // Calculate average color for the block instead of just top-left pixel
          let totalR = 0, totalG = 0, totalB = 0, totalA = 0, count = 0
          
          // Sample multiple pixels in the block for better color representation
          for (let dy = 0; dy < pixelSize && y + dy < targetSize; dy++) {
            for (let dx = 0; dx < pixelSize && x + dx < targetSize; dx++) {
              const pixelIndex = ((y + dy) * targetSize + (x + dx)) * 4
              totalR += data[pixelIndex]
              totalG += data[pixelIndex + 1]
              totalB += data[pixelIndex + 2]
              totalA += data[pixelIndex + 3]
              count++
            }
          }
          
          // Calculate average colors
          const avgR = Math.round(totalR / count)
          const avgG = Math.round(totalG / count)
          const avgB = Math.round(totalB / count)
          const avgA = Math.round(totalA / count)
          
          // Fill the entire block with the average color
          for (let dy = 0; dy < pixelSize && y + dy < targetSize; dy++) {
            for (let dx = 0; dx < pixelSize && x + dx < targetSize; dx++) {
              const blockPixelIndex = ((y + dy) * targetSize + (x + dx)) * 4
              data[blockPixelIndex] = avgR
              data[blockPixelIndex + 1] = avgG
              data[blockPixelIndex + 2] = avgB
              data[blockPixelIndex + 3] = avgA
            }
          }
        }
      }
      
      // Put the pixelated data back
      ctx.putImageData(imageData, 0, 0)
      
      // Return as data URL
      resolve(canvas.toDataURL())
    }
    
    img.src = imageData
  })
}

function HomePage() {
  const [selectedImage, setSelectedImage] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState('')
  const fileInputRef = useRef(null)
  const navigate = useNavigate()

  // Check if user is already "logged in" from localStorage
  useEffect(() => {
    const savedLogin = localStorage.getItem('marioLogin')
    if (savedLogin) {
      const loginData = JSON.parse(savedLogin)
      setIsLoggedIn(true)
      setUsername(loginData.username)
    }
  }, [])

  // Fake login function
  const handleLogin = () => {
    const marioNames = [
      'Mario', 'Luigi', 'Princess Peach', 'Toad', 'Yoshi', 
      'Bowser', 'Koopa', 'Goomba', 'Shy Guy', 'Piranha Plant'
    ]
    const randomName = marioNames[Math.floor(Math.random() * marioNames.length)]
    
    setIsLoggedIn(true)
    setUsername(randomName)
    
    // Save to localStorage
    localStorage.setItem('marioLogin', JSON.stringify({
      username: randomName,
      loginTime: new Date().toISOString()
    }))
    
    // Show a fun Mario-style alert
    alert(`🍄 Welcome back, ${randomName}! Let's-a-go save the environment! 🌱`)
  }

  // Fake logout function
  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsername('')
    localStorage.removeItem('marioLogin')
    alert(`👋 Goodbye! Thanks for helping save the Mushroom Kingdom! 🍄`)
  }

  const handleImageUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      setSelectedImage(file)
      setError(null)
      setResult(null)
      
      // Create preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const classifyImage = async () => {
    if (!selectedImage) return

    setIsLoading(true)
    setError(null)

    try {
      // Create FormData for file upload
      const formData = new FormData()
      formData.append('image', selectedImage)

      // Call the backend API
      const response = await fetch('https://y0h0i3cywyye.manus.space/api/classify', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Classification failed')
      }

      const data = await response.json()
      
      const classificationResult = {
        item: data.item,
        confidence: data.confidence,
        carbonData: data.carbonData
      }
      
      setResult(classificationResult)
      
      // Create pixelated version and save to localStorage
      if (imagePreview) {
        const pixelatedImage = await pixelateImage(imagePreview)
        
        // Save to localStorage
        const recycledItem = {
          ...classificationResult,
          pixelatedImage,
          originalImage: imagePreview,
          timestamp: new Date().toISOString(),
          itemName: data.item
        }
        
        const existingItems = JSON.parse(localStorage.getItem('recycledItems') || '[]')
        existingItems.push(recycledItem)
        localStorage.setItem('recycledItems', JSON.stringify(existingItems))
      }
      
    } catch (err) {
      setError("Classification failed. Please try another image.")
      console.error('Classification error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const resetApp = () => {
    setSelectedImage(null)
    setImagePreview(null)
    setResult(null)
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const getEmissionColor = (co2Value) => {
    if (co2Value < 0.1) return 'bg-green-500'
    if (co2Value < 1.0) return 'bg-yellow-500'
    if (co2Value < 10.0) return 'bg-orange-500'
    return 'bg-red-500'
  }

  return (
    <div className="min-h-screen mario-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="mario-pattern"></div>
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header with Login Button */}
        <div className="flex justify-between items-start mb-8">
          <div className="flex-1"></div>
          <div className="text-center flex-1">
            <h1 className="text-6xl font-bold text-yellow-400 mb-4 pixel-font mario-title drop-shadow-lg">
              🍄 EcoMario 🌱
            </h1>
            <p className="text-xl text-yellow-300 pixel-font drop-shadow-md">
              Discover the carbon footprint of everyday items!
            </p>
          </div>
          <div className="flex-1 flex justify-end">
            {!isLoggedIn ? (
              <Button
                onClick={handleLogin}
                className="mario-login-button bg-red-600 hover:bg-red-700 text-white px-4 py-2 text-sm pixel-font border-4 border-red-800 shadow-lg rounded-lg"
              >
                🍄 Login
              </Button>
            ) : (
              <div className="flex flex-col items-end gap-2">
                <div className="text-sm pixel-font text-yellow-400 font-bold">
                  Welcome, {username}!
                </div>
                <Button
                  onClick={handleLogout}
                  className="mario-login-button bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 text-sm pixel-font border-4 border-gray-800 shadow-lg rounded-lg"
                >
                  👋 Logout
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Navigation to Recycled Items */}
        <div className="text-center mb-6">
          <Button
            onClick={() => navigate('/recycled')}
            className="mario-button bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 text-lg pixel-font border-4 border-purple-800 shadow-lg"
          >
            <Package className="mr-2 h-5 w-5" />
            See My Recycled Items
          </Button>
        </div>

        <div className="max-w-2xl mx-auto">
          {!result ? (
            <Card className="mario-card border-4 border-green-600 shadow-2xl">
              <CardHeader className="text-center bg-green-100">
                <CardTitle className="text-2xl text-green-800 pixel-font">
                  Upload an Item Photo
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                {/* Upload Area */}
                <div 
                  className="mario-upload-area border-4 border-dashed border-green-400 rounded-lg p-8 text-center cursor-pointer hover:border-green-600 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {imagePreview ? (
                    <div className="space-y-4">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="max-w-full max-h-64 mx-auto rounded-lg shadow-lg"
                      />
                      <p className="text-green-700 pixel-font">Image ready for classification!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="mario-question-block mx-auto w-24 h-24 bg-yellow-400 border-4 border-yellow-600 rounded-lg flex items-center justify-center text-4xl font-bold text-white shadow-lg hover:bg-yellow-300 transition-colors">
                        ?
                      </div>
                      <div>
                        <Upload className="mx-auto h-12 w-12 text-green-600 mb-4" />
                        <p className="text-lg text-green-700 pixel-font">
                          Click to upload or drag & drop
                        </p>
                        <p className="text-sm text-green-600 mt-2">
                          Supports: Plastic Bottle, Aluminum Can, T-Shirt, Banana, Glass Bottle, Laptop, Paper Sheet
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />

                {/* Action Buttons */}
                <div className="mt-6 flex gap-4 justify-center">
                  {selectedImage && (
                    <Button
                      onClick={classifyImage}
                      disabled={isLoading}
                      className="mario-button bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg pixel-font border-4 border-green-800 shadow-lg"
                    >
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="mario-spinner w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                          Analyzing...
                        </div>
                      ) : (
                        <>
                          <Zap className="mr-2 h-5 w-5" />
                          Classify Item
                        </>
                      )}
                    </Button>
                  )}
                  
                  {selectedImage && (
                    <Button
                      onClick={resetApp}
                      variant="outline"
                      className="mario-button-secondary border-4 border-gray-400 px-6 py-3 text-lg pixel-font"
                    >
                      Reset
                    </Button>
                  )}
                </div>

                {error && (
                  <div className="mt-4 p-4 bg-red-100 border-4 border-red-400 rounded-lg">
                    <div className="flex items-center gap-2 text-red-700">
                      <AlertCircle className="h-5 w-5" />
                      <span className="pixel-font">{error}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            /* Results Card */
            <Card className="mario-result-card border-4 border-yellow-600 shadow-2xl bg-yellow-50">
              <CardHeader className="text-center bg-yellow-100 border-b-4 border-yellow-600">
                <CardTitle className="text-3xl text-yellow-800 pixel-font">
                  🎉 Classification Complete! 🎉
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <div className="text-center space-y-6">
                  {/* Item Display */}
                  <div className="mario-item-display bg-white border-4 border-yellow-400 rounded-lg p-6">
                    <div className="text-6xl mb-4">
                      {typeof itemIcons[result.item] === 'string' && itemIcons[result.item].startsWith('/') ? (
                        <img 
                          src={itemIcons[result.item]} 
                          alt={result.item}
                          className="w-16 h-16 mx-auto pixelated"
                        />
                      ) : (
                        itemIcons[result.item]
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800 pixel-font">
                      {result.item}
                    </h3>
                    <p className="text-lg text-gray-600 pixel-font">
                      Confidence: {(result.confidence * 100).toFixed(1)}%
                    </p>
                  </div>

                  {/* Carbon Footprint Data */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* CO2 Produced */}
                    <div className="mario-stat-card bg-red-100 border-4 border-red-400 rounded-lg p-4">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <span className="text-2xl">💨</span>
                        <span className="pixel-font font-bold text-red-700">CO₂ Produced</span>
                      </div>
                      <div className="text-3xl font-bold text-red-800 pixel-font">
                        {result.carbonData.co2_produced} kg
                      </div>
                      <div className={`mt-2 h-3 rounded-full ${getEmissionColor(result.carbonData.co2_produced)}`}></div>
                    </div>

                    {/* CO2 Saved */}
                    <div className="mario-stat-card bg-green-100 border-4 border-green-400 rounded-lg p-4">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Leaf className="h-6 w-6 text-green-600" />
                        <span className="pixel-font font-bold text-green-700">CO₂ Saved</span>
                      </div>
                      <div className="text-3xl font-bold text-green-800 pixel-font">
                        {result.carbonData.co2_saved} kg
                      </div>
                      <div className={`mt-2 h-3 rounded-full ${getEmissionColor(result.carbonData.co2_saved)}`}></div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-4 justify-center">
                    <Button
                      onClick={resetApp}
                      className="mario-button-large bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-xl pixel-font border-4 border-blue-800 shadow-lg transform hover:scale-105 transition-transform"
                    >
                      🚀 Try Another Item!
                    </Button>
                    
                    <Button
                      onClick={() => navigate('/recycled')}
                      className="mario-button-large bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-xl pixel-font border-4 border-purple-800 shadow-lg transform hover:scale-105 transition-transform"
                    >
                      <Package className="mr-2 h-5 w-5" />
                      View Collection
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default HomePage

