import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Upload, Leaf, Zap, AlertCircle } from 'lucide-react'
import './App.css'

// Carbon footprint data
const carbonData = {
  "Plastic Bottle": { co2_produced: 0.1, co2_saved: 0.08 },
  "Aluminum Can": { co2_produced: 1.6, co2_saved: 1.4 },
  "T-Shirt": { co2_produced: 2.0, co2_saved: 1.2 },
  "Banana": { co2_produced: 0.08, co2_saved: 0.0 },
  "Glass Bottle": { co2_produced: 0.5, co2_saved: 0.3 },
  "Laptop": { co2_produced: 200.0, co2_saved: 5.0 },
  "Paper Sheet": { co2_produced: 0.005, co2_saved: 0.004 }
}

// Recycling tips data
const recyclingTips = {
  "T-Shirt": {
    title: "👕 T-Shirt",
    intro: "That T-shirt's had more lives than a 1-Up Mushroom — but it doesn't have to end in a landfill!",
    facts: "Cotton takes months to decompose, and synthetic fibers can take decades.",
    tips: "Instead of tossing it, donate if it's wearable, or recycle it at textile drop-offs. Some programs even turn old fabric into insulation or industrial rags.",
    conclusion: "It's like giving your shirt a power-up — from fashion to function!"
  },
  "Plastic Bottle": {
    title: "🍼 Plastic Bottle",
    intro: "Looks like a simple water bottle, but it's secretly a long-term boss battle for the planet!",
    facts: "Most plastic bottles are made from PET, which is recyclable — but only if rinsed and emptied.",
    tips: "If it ends up in the wrong bin, it might go on a 400-year adventure… in a landfill.",
    conclusion: "Recycle it properly and it could become a new bottle or a fleece jacket faster than Mario gets through World 1-1!"
  },
  "Aluminum Can": {
    title: "🥫 Aluminum Can",
    intro: "Aluminum cans are basically the superstar of recycling — infinite lives, zero level resets.",
    facts: "Recycling one can saves enough energy to power a game console for 3 hours.",
    tips: "Unlike plastics, aluminum doesn't degrade when recycled. Clean it, crush it, and send it back — it could be reborn as a new can in less than 60 days.",
    conclusion: "That's faster than Lakitu's respawn timer!"
  },
  "Glass Bottle": {
    title: "🍾 Glass Bottle",
    intro: "Glass: the elegant, durable item that — plot twist — doesn't decompose at all.",
    facts: "Properly sorted by color (clear, brown, green), glass can be recycled endlessly without losing quality.",
    tips: "It takes less energy to recycle glass than to make new glass from sand (which is, by the way, running out!).",
    conclusion: "Sort it right or risk sending it on a thousand-year slumber in the landfill dungeon."
  },
  "Laptop": {
    title: "💻 Laptop",
    intro: "A retired laptop is no ordinary junk — it's a treasure chest of rare Earth elements!",
    facts: "Inside your device are metals like gold, lithium, and cobalt, which are expensive to mine and toxic to toss.",
    tips: "Recycling e-waste keeps toxins out of water and lets manufacturers reuse parts, reducing the need for mining.",
    conclusion: "So don't yeet it like a Koopa shell — drop it off at an e-waste center or certified electronics recycler."
  },
  "Paper Sheet": {
    title: "📄 Paper Sheet",
    intro: "Paper seems harmless… until you realize how many forests are stuck in Bowser's castle.",
    facts: "Recycling one ton of paper saves about 17 trees, 7,000 gallons of water, and enough energy to power a house for six months.",
    tips: "Just keep it clean — no pizza grease, glitter, or rogue Goomba footprints.",
    conclusion: "Bonus XP if you print double-sided or reuse for notes before recycling!"
  },
  "Banana": {
    title: "🍌 Banana",
    intro: "A banana peel might seem harmless, but it's got some eco-secrets!",
    facts: "Banana peels decompose in 2-5 weeks, making them great for composting.",
    tips: "Toss it in your compost bin or use it as natural fertilizer for plants. The potassium helps plants grow stronger!",
    conclusion: "Turn that peel into plant power-ups — nature's own 1-Up mushroom!"
  }
}

// Item icons mapping
const itemIcons = {
  "Plastic Bottle": "/src/assets/plastic-bottle-icon.png",
  "Aluminum Can": "/src/assets/aluminum-can-icon.png",
  "T-Shirt": "👕",
  "Banana": "🍌",
  "Glass Bottle": "🍾",
  "Laptop": "💻",
  "Paper Sheet": "📄"
}

function App() {
  const [selectedImage, setSelectedImage] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [showRecyclingTips, setShowRecyclingTips] = useState(false)
  const [marioAnimation, setMarioAnimation] = useState(false)
  const [blockAnimation, setBlockAnimation] = useState(false)
  const fileInputRef = useRef(null)

  const handleImageUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      setSelectedImage(file)
      setError(null)
      setResult(null)
      
      // Create preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const classifyImage = async () => {
    if (!selectedImage) return

    setIsLoading(true)
    setError(null)

    try {
      console.log('Starting classification...')
      console.log('Selected image:', selectedImage)
      console.log('Image type:', selectedImage.type)
      console.log('Image size:', selectedImage.size)
      
      // Create FormData to send the image file
      const formData = new FormData()
      formData.append('image', selectedImage)
      
      console.log('FormData created, sending request...')

      // Call the Flask backend API
      const response = await fetch('https://qjh9iecej8pm.manus.space/api/classify', {
        method: 'POST',
        body: formData,
      })

      console.log('Response received:', response.status, response.statusText)

      if (!response.ok) {
        const errorText = await response.text()
        console.log('Error response:', errorText)
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      console.log('Classification result:', data)
      
      setResult({
        item: data.item,
        confidence: data.confidence,
        carbonData: data.carbonData
      })
      
      // Trigger recycling tips animation after a short delay
      setTimeout(() => {
        triggerRecyclingTips()
      }, 1500)
    } catch (err) {
      console.error('Classification error:', err)
      setError("Classification failed. Please try another image.")
    } finally {
      setIsLoading(false)
    }
  }

  const triggerRecyclingTips = () => {
    // Start Mario jumping animation
    setMarioAnimation(true)
    
    // After Mario jumps, hit the block
    setTimeout(() => {
      setBlockAnimation(true)
    }, 800)
    
    // Show recycling tips after block is hit
    setTimeout(() => {
      setShowRecyclingTips(true)
    }, 1200)
    
    // Reset animations
    setTimeout(() => {
      setMarioAnimation(false)
      setBlockAnimation(false)
    }, 2000)
  }

  const resetApp = () => {
    setSelectedImage(null)
    setImagePreview(null)
    setResult(null)
    setError(null)
    setShowRecyclingTips(false)
    setMarioAnimation(false)
    setBlockAnimation(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const getEmissionColor = (co2Value) => {
    if (co2Value < 0.1) return 'bg-green-500'
    if (co2Value < 1.0) return 'bg-yellow-500'
    if (co2Value < 10.0) return 'bg-orange-500'
    return 'bg-red-500'
  }

  return (
    <div className="min-h-screen mario-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="mario-pattern"></div>
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold text-green-800 mb-4 pixel-font mario-title">
            🍄 EcoMario 🌱
          </h1>
          <p className="text-xl text-green-700 pixel-font">
            Discover the carbon footprint of everyday items!
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          {!result ? (
            <Card className="mario-card border-4 border-green-600 shadow-2xl">
              <CardHeader className="text-center bg-green-100">
                <CardTitle className="text-2xl text-green-800 pixel-font">
                  Upload an Item Photo
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                {/* Upload Area */}
                <div 
                  className="mario-upload-area border-4 border-dashed border-green-400 rounded-lg p-8 text-center cursor-pointer hover:border-green-600 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {imagePreview ? (
                    <div className="space-y-4">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="max-w-full max-h-64 mx-auto rounded-lg shadow-lg"
                      />
                      <p className="text-green-700 pixel-font">Image ready for classification!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="mario-question-block mx-auto w-24 h-24 bg-yellow-400 border-4 border-yellow-600 rounded-lg flex items-center justify-center text-4xl font-bold text-white shadow-lg hover:bg-yellow-300 transition-colors">
                        ?
                      </div>
                      <div>
                        <Upload className="mx-auto h-12 w-12 text-green-600 mb-4" />
                        <p className="text-lg text-green-700 pixel-font">
                          Click to upload or drag & drop
                        </p>
                        <p className="text-sm text-green-600 mt-2">
                          Supports: Plastic Bottle, Aluminum Can, T-Shirt, Banana, Glass Bottle, Laptop, Paper Sheet
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />

                {/* Action Buttons */}
                <div className="mt-6 flex gap-4 justify-center">
                  {selectedImage && (
                    <Button
                      onClick={classifyImage}
                      disabled={isLoading}
                      className="mario-button bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg pixel-font border-4 border-green-800 shadow-lg"
                    >
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="mario-spinner w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                          Analyzing...
                        </div>
                      ) : (
                        <>
                          <Zap className="mr-2 h-5 w-5" />
                          Classify Item
                        </>
                      )}
                    </Button>
                  )}
                  
                  {selectedImage && (
                    <Button
                      onClick={resetApp}
                      variant="outline"
                      className="mario-button-secondary border-4 border-gray-400 px-6 py-3 text-lg pixel-font"
                    >
                      Reset
                    </Button>
                  )}
                </div>

                {error && (
                  <div className="mt-4 p-4 bg-red-100 border-4 border-red-400 rounded-lg">
                    <div className="flex items-center gap-2 text-red-700">
                      <AlertCircle className="h-5 w-5" />
                      <span className="pixel-font">{error}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            /* Results Card */
            <Card className="mario-result-card border-4 border-yellow-600 shadow-2xl bg-yellow-50">
              <CardHeader className="text-center bg-yellow-100 border-b-4 border-yellow-600">
                <CardTitle className="text-3xl text-yellow-800 pixel-font">
                  🎉 Classification Complete! 🎉
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <div className="text-center space-y-6">
                  {/* Item Display */}
                  <div className="mario-item-display bg-white border-4 border-yellow-400 rounded-lg p-6">
                    <div className="text-6xl mb-4">
                      {typeof itemIcons[result.item] === 'string' && itemIcons[result.item].startsWith('/') ? (
                        <img 
                          src={itemIcons[result.item]} 
                          alt={result.item}
                          className="w-16 h-16 mx-auto pixelated"
                        />
                      ) : (
                        itemIcons[result.item]
                      )}
                    </div>
                    <h3 className="text-2xl font-bold text-gray-800 pixel-font">
                      {result.item}
                    </h3>
                    <p className="text-lg text-gray-600 pixel-font">
                      Confidence: {(result.confidence * 100).toFixed(1)}%
                    </p>
                  </div>

                  {/* Carbon Footprint Data */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* CO2 Produced */}
                    <div className="mario-stat-card bg-red-100 border-4 border-red-400 rounded-lg p-4">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <span className="text-2xl">💨</span>
                        <span className="pixel-font font-bold text-red-700">CO₂ Produced</span>
                      </div>
                      <div className="text-3xl font-bold text-red-800 pixel-font">
                        {result.carbonData.co2_produced} kg
                      </div>
                      <div className={`mt-2 h-3 rounded-full ${getEmissionColor(result.carbonData.co2_produced)}`}></div>
                    </div>

                    {/* CO2 Saved */}
                    <div className="mario-stat-card bg-green-100 border-4 border-green-400 rounded-lg p-4">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Leaf className="h-6 w-6 text-green-600" />
                        <span className="pixel-font font-bold text-green-700">CO₂ Saved</span>
                      </div>
                      <div className="text-3xl font-bold text-green-800 pixel-font">
                        {result.carbonData.co2_saved} kg
                      </div>
                      <div className={`mt-2 h-3 rounded-full ${getEmissionColor(result.carbonData.co2_saved)}`}></div>
                    </div>
                  </div>

                  {/* Mario Animation and Recycling Tips */}
                  <div className="relative">
                    {/* Mario Animation */}
                    <div className={`mario-animation-container ${marioAnimation ? 'animate' : ''}`}>
                      <img 
                        src="/src/assets/mario-character.png" 
                        alt="Mario" 
                        className={`mario-character ${marioAnimation ? 'jumping' : ''}`}
                      />
                    </div>
                    
                    {/* Question Block */}
                    <div className={`question-block-container ${blockAnimation ? 'hit' : ''}`}>
                      <img 
                        src="/src/assets/question-block.png" 
                        alt="Question Block" 
                        className={`question-block ${blockAnimation ? 'bouncing' : ''}`}
                      />
                    </div>
                    
                    {/* Recycling Tips */}
                    {showRecyclingTips && result && recyclingTips[result.item] && (
                      <div className="recycling-tips-card mario-tips-card bg-white border-4 border-green-500 rounded-lg p-6 mt-6 shadow-xl animate-fadeInUp">
                        <div className="text-center space-y-4">
                          <h3 className="text-2xl font-bold text-green-800 pixel-font">
                            ♻️ Recycling Tips ♻️
                          </h3>
                          
                          <div className="text-left space-y-3">
                            <h4 className="text-xl font-bold text-green-700 pixel-font">
                              {recyclingTips[result.item].title}
                            </h4>
                            
                            <p className="text-green-800 pixel-font text-sm leading-relaxed">
                              {recyclingTips[result.item].intro}
                            </p>
                            
                            <p className="text-green-700 pixel-font text-sm leading-relaxed">
                              <strong>Facts:</strong> {recyclingTips[result.item].facts}
                            </p>
                            
                            <p className="text-green-700 pixel-font text-sm leading-relaxed">
                              <strong>Tips:</strong> {recyclingTips[result.item].tips}
                            </p>
                            
                            <p className="text-green-800 pixel-font text-sm leading-relaxed font-bold">
                              {recyclingTips[result.item].conclusion}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Try Again Button */}
                  <Button
                    onClick={resetApp}
                    className="mario-button-large bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 text-xl pixel-font border-4 border-blue-800 shadow-lg transform hover:scale-105 transition-transform"
                  >
                    🚀 Try Another Item!
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default App

