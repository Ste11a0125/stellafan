import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { ArrowLeft, Trash2, Star, Trophy, Coins } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

function RecycledItems() {
  const [recycledItems, setRecycledItems] = useState([])
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    // Load recycled items from localStorage
    const savedItems = localStorage.getItem('recycledItems')
    if (savedItems) {
      setRecycledItems(JSON.parse(savedItems))
    }

    // Check if user is already "logged in" from localStorage
    const savedLogin = localStorage.getItem('marioLogin')
    if (savedLogin) {
      const loginData = JSON.parse(savedLogin)
      setIsLoggedIn(true)
      setUsername(loginData.username)
    }
  }, [])

  // Fake login function
  const handleLogin = () => {
    const marioNames = [
      'Mario', 'Luigi', 'Princess Peach', 'Toad', 'Yoshi', 
      'Bowser', 'Koopa', 'Goomba', 'Shy Guy', 'Piranha Plant'
    ]
    const randomName = marioNames[Math.floor(Math.random() * marioNames.length)]
    
    setIsLoggedIn(true)
    setUsername(randomName)
    
    // Save to localStorage
    localStorage.setItem('marioLogin', JSON.stringify({
      username: randomName,
      loginTime: new Date().toISOString()
    }))
    
    // Show a fun Mario-style alert
    alert(`🍄 Welcome back, ${randomName}! Let's-a-go save the environment! 🌱`)
  }

  // Fake logout function
  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsername('')
    localStorage.removeItem('marioLogin')
    alert(`👋 Goodbye! Thanks for helping save the Mushroom Kingdom! 🍄`)
  }

  const clearAllItems = () => {
    localStorage.removeItem('recycledItems')
    setRecycledItems([])
  }

  const removeItem = (index) => {
    const updatedItems = recycledItems.filter((_, i) => i !== index)
    setRecycledItems(updatedItems)
    localStorage.setItem('recycledItems', JSON.stringify(updatedItems))
  }

  const getCollectionLevel = (itemCount) => {
    if (itemCount >= 20) return { level: 'Master Recycler', icon: '👑', color: 'text-yellow-600' }
    if (itemCount >= 15) return { level: 'Eco Champion', icon: '🏆', color: 'text-purple-600' }
    if (itemCount >= 10) return { level: 'Green Hero', icon: '⭐', color: 'text-blue-600' }
    if (itemCount >= 5) return { level: 'Eco Warrior', icon: '🌟', color: 'text-green-600' }
    return { level: 'Beginner', icon: '🌱', color: 'text-gray-600' }
  }

  const collectionLevel = getCollectionLevel(recycledItems.length)

  return (
    <div className="min-h-screen mario-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="mario-pattern"></div>
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header with Login Button */}
        <div className="flex justify-between items-start mb-8">
          <div className="flex-1"></div>
          <div className="text-center flex-1">
            <h1 className="text-6xl font-bold text-yellow-400 mb-4 pixel-font mario-title drop-shadow-lg">
              🏆 My Recycled Items 🌱
            </h1>
            <p className="text-xl text-yellow-300 pixel-font drop-shadow-md">
              Your collection of eco-friendly items!
            </p>
            
            {/* Collection Level Badge */}
            <div className="mt-4 inline-flex items-center gap-2 bg-white border-4 border-yellow-400 rounded-lg px-6 py-3 shadow-lg">
              <span className="text-2xl">{collectionLevel.icon}</span>
              <span className={`pixel-font font-bold text-lg ${collectionLevel.color}`}>
                {collectionLevel.level}
              </span>
            </div>
          </div>
          <div className="flex-1 flex justify-end">
            {!isLoggedIn ? (
              <Button
                onClick={handleLogin}
                className="mario-login-button bg-red-600 hover:bg-red-700 text-white px-4 py-2 text-sm pixel-font border-4 border-red-800 shadow-lg rounded-lg"
              >
                🍄 Login
              </Button>
            ) : (
              <div className="flex flex-col items-end gap-2">
                <div className="text-sm pixel-font text-yellow-400 font-bold">
                  Welcome, {username}!
                </div>
                <Button
                  onClick={handleLogout}
                  className="mario-login-button bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 text-sm pixel-font border-4 border-gray-800 shadow-lg rounded-lg"
                >
                  👋 Logout
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mb-8">
          <Button
            onClick={() => navigate('/')}
            className="mario-button bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 text-lg pixel-font border-4 border-blue-800 shadow-lg"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Upload
          </Button>
          
          {recycledItems.length > 0 && (
            <Button
              onClick={clearAllItems}
              variant="destructive"
              className="mario-button bg-red-600 hover:bg-red-700 text-white px-6 py-3 text-lg pixel-font border-4 border-red-800 shadow-lg"
            >
              <Trash2 className="mr-2 h-5 w-5" />
              Clear All
            </Button>
          )}
        </div>

        {/* Collection Shelf */}
        <Card className="mario-card border-4 border-yellow-600 shadow-2xl bg-yellow-50">
          <CardHeader className="text-center bg-yellow-100 border-b-4 border-yellow-600">
            <CardTitle className="text-3xl text-yellow-800 pixel-font flex items-center justify-center gap-3">
              🪵 Mario's Collection Shelf 🪵
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            {recycledItems.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-8xl mb-4">📦</div>
                <h3 className="text-2xl font-bold text-gray-600 pixel-font mb-4">
                  No items yet!
                </h3>
                <p className="text-lg text-gray-500 pixel-font mb-6">
                  Upload and classify some items to see them here as pixelated collectibles!
                </p>
                <div className="mario-empty-shelf bg-gradient-to-b from-amber-600 to-amber-800 border-4 border-amber-900 rounded-lg h-32 mx-auto max-w-md relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-amber-300 pixel-font text-lg opacity-50">Empty Shelf</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mario-shelf-container">
                {/* Multiple Wooden Shelves */}
                {Array.from({ length: Math.ceil(recycledItems.length / 6) }, (_, shelfIndex) => (
                  <div key={shelfIndex} className="mario-wooden-shelf bg-gradient-to-b from-amber-600 to-amber-800 border-4 border-amber-900 rounded-lg p-6 mb-6 relative">
                    {/* Shelf decorations */}
                    <div className="absolute -top-2 left-4 w-4 h-4 bg-amber-900 rounded-full"></div>
                    <div className="absolute -top-2 right-4 w-4 h-4 bg-amber-900 rounded-full"></div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {recycledItems.slice(shelfIndex * 6, (shelfIndex + 1) * 6).map((item, index) => {
                        const globalIndex = shelfIndex * 6 + index
                        return (
                          <div
                            key={globalIndex}
                            className="mario-collectible-item relative group"
                            style={{ '--index': index }}
                          >
                            {/* Pixelated Image */}
                            <div className="mario-item-frame bg-white border-4 border-gray-400 rounded-lg p-2 shadow-lg hover:shadow-xl transition-all duration-300 relative">
                              <img
                                src={item.pixelatedImage}
                                alt={item.itemName}
                                className="w-full h-20 object-cover pixelated rounded"
                              />
                              
                              {/* Rarity indicator */}
                              <div className="absolute top-1 right-1">
                                {item.confidence > 0.9 ? (
                                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                ) : item.confidence > 0.8 ? (
                                  <Star className="w-4 h-4 text-blue-500 fill-current" />
                                ) : (
                                  <Star className="w-4 h-4 text-gray-400 fill-current" />
                                )}
                              </div>
                              
                              {/* Item Info Tooltip */}
                              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white text-xs rounded px-3 py-2 pixel-font whitespace-nowrap z-10 pointer-events-none">
                                <div className="font-bold">{item.itemName}</div>
                                <div>Confidence: {(item.confidence * 100).toFixed(1)}%</div>
                                <div>CO₂ Saved: {item.carbonData?.co2_saved || 0} kg</div>
                                <div className="text-xs opacity-75">
                                  {new Date(item.timestamp).toLocaleDateString()}
                                </div>
                                {/* Tooltip arrow */}
                                <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black"></div>
                              </div>
                              
                              {/* Remove Button */}
                              <button
                                onClick={() => removeItem(globalIndex)}
                                className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity border-2 border-white shadow-lg"
                              >
                                ×
                              </button>
                            </div>
                            
                            {/* Item Label */}
                            <div className="text-center mt-2">
                              <span className="text-xs pixel-font text-amber-900 font-bold block truncate">
                                {item.itemName}
                              </span>
                              <span className="text-xs pixel-font text-amber-700 opacity-75">
                                {(item.confidence * 100).toFixed(0)}%
                              </span>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                ))}
                
                {/* Collection Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8">
                  <div className="mario-stat-card bg-green-100 border-4 border-green-400 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Trophy className="h-6 w-6 text-green-600 mr-2" />
                    </div>
                    <div className="text-3xl font-bold text-green-800 pixel-font">
                      {recycledItems.length}
                    </div>
                    <div className="text-sm text-green-700 pixel-font">
                      Items Collected
                    </div>
                  </div>
                  
                  <div className="mario-stat-card bg-blue-100 border-4 border-blue-400 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <span className="text-2xl">🌍</span>
                    </div>
                    <div className="text-3xl font-bold text-blue-800 pixel-font">
                      {recycledItems.reduce((total, item) => total + (item.carbonData?.co2_saved || 0), 0).toFixed(2)}
                    </div>
                    <div className="text-sm text-blue-700 pixel-font">
                      Total CO₂ Saved (kg)
                    </div>
                  </div>
                  
                  <div className="mario-stat-card bg-purple-100 border-4 border-purple-400 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Star className="h-6 w-6 text-purple-600 mr-2" />
                    </div>
                    <div className="text-3xl font-bold text-purple-800 pixel-font">
                      {recycledItems.length > 0 ? Math.round(recycledItems.reduce((total, item) => total + (item.confidence || 0), 0) / recycledItems.length * 100) : 0}%
                    </div>
                    <div className="text-sm text-purple-700 pixel-font">
                      Avg Confidence
                    </div>
                  </div>
                  
                  <div className="mario-stat-card bg-yellow-100 border-4 border-yellow-400 rounded-lg p-4 text-center">
                    <div className="flex items-center justify-center mb-2">
                      <Coins className="h-6 w-6 text-yellow-600 mr-2" />
                    </div>
                    <div className="text-3xl font-bold text-yellow-800 pixel-font">
                      {recycledItems.filter(item => item.confidence > 0.8).length}
                    </div>
                    <div className="text-sm text-yellow-700 pixel-font">
                      High Quality Items
                    </div>
                  </div>
                </div>

                {/* Achievement Badges */}
                <div className="mt-8 text-center">
                  <h3 className="text-2xl font-bold text-gray-800 pixel-font mb-4">🏅 Achievements</h3>
                  <div className="flex flex-wrap justify-center gap-4">
                    {recycledItems.length >= 1 && (
                      <div className="bg-white border-4 border-green-400 rounded-lg px-4 py-2 shadow-lg">
                        <span className="text-lg">🌱</span>
                        <span className="pixel-font text-sm text-green-700 ml-2">First Item</span>
                      </div>
                    )}
                    {recycledItems.length >= 5 && (
                      <div className="bg-white border-4 border-blue-400 rounded-lg px-4 py-2 shadow-lg">
                        <span className="text-lg">🌟</span>
                        <span className="pixel-font text-sm text-blue-700 ml-2">Eco Warrior</span>
                      </div>
                    )}
                    {recycledItems.length >= 10 && (
                      <div className="bg-white border-4 border-purple-400 rounded-lg px-4 py-2 shadow-lg">
                        <span className="text-lg">⭐</span>
                        <span className="pixel-font text-sm text-purple-700 ml-2">Green Hero</span>
                      </div>
                    )}
                    {recycledItems.filter(item => item.confidence > 0.9).length >= 3 && (
                      <div className="bg-white border-4 border-yellow-400 rounded-lg px-4 py-2 shadow-lg">
                        <span className="text-lg">🎯</span>
                        <span className="pixel-font text-sm text-yellow-700 ml-2">Accuracy Master</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default RecycledItems

